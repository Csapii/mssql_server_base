<script>
import { usePackageStore } from '@stores/PackageStore.mjs';
import { useCustomerStore } from '@stores/CustomerStore.mjs';

export default {
  mounted() {
    usePackageStore().getPackages();
    useCustomerStore().getCustomers();
  }
}
</script>

<template>
  <RouterView />
</template>
