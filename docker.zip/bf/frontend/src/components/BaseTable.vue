<template>
    <table class="mx-auto border border-black">
        <thead class="bg-green-300">
            <tr>
                <th class="p-5">Név</th>
                <th class="p-5">Születési év</th>
                <th class="p-5">Státusz</th>
            </tr>
        </thead>
        <tbody>
            <tr class="even:bg-gray-200" v-for="customer in customers" :key="customer.id">
                <td class="p-5">{{ customer.name }}</td>
                <td class="p-5">{{ customer.birth }}</td>
                <td class="p-5">{{ customer.business === true ? 'Cég' : 'Magánszemély' }}</td>
            </tr>
        </tbody>
    </table>
</template>

<script>
export default {
    props: {
        customers: Array
    }
}
</script>