<template>
    <RouterLink :to="{ name: 'single-package', params: { id: pack.id } }">
        <div class="border border-black rounded-md p-2 hover:shadow-lg">
            <h2 class="font-bold text-center">{{ pack.name }}</h2>
            <div class="flex flex-row gap-3 justify-center pt-3">
                <span class="p-1 rounded-md bg-blue-300">{{ pack.type }}</span>
                <span class="p-1 rounded-md bg-green-300">{{ pack.price }} Ft</span>
            </div>
        </div>
    </RouterLink>
</template>

<script>
export default {
    props: {
        pack: Object
    }
}
</script>