import { defineStore } from "pinia";
import { http } from "@utils/http";

export const usePackageStore = defineStore("package-store", {
    state() {
        return {
            packages: [],
        };
    },

    actions: {
        async getPackages() {
            const response = await http.get("/packages");
            this.packages = response.data.data;
        },

        async getPackage(id) {
            const response = await http.get(`/packages/${id}`);
            return response.data.data;
        },
    },

    getters: {
        packageOptions() {
            return this.packages.map((pack) => ({
                label: pack.name,
                value: pack.id,
            }));
        },
    },
});
