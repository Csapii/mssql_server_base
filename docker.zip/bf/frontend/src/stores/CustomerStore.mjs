import { defineStore } from "pinia";
import { http } from "@utils/http";

export const useCustomerStore = defineStore('customer-store', {
    state() {
        return {
            customers: []
        }
    },

    actions: {
        async getCustomers() {
            const response = await http.get('/customers');
            this.customers = response.data.data;
        },

        async createCustomer(data) {
            const response = await http.post('/customers', data);
            this.customers.push(response.data.data);
        }
    }
});