<template>
    <BaseLayout>
        <FormKit type="form" :actions="false" @submit="newCustomer">
            <FormKit type="text" name="name" label="Név:" validation="required|length:0,25" />
            <FormKit type="number" name="birth" label="Születési év:" validation="required|number|between:1900,2025" />
            <FormKit type="select" name="business" label="Státusz:" validation="required"
                :options="[{ label: 'Magánszemély', value: false }, { label: 'Cég', value: true }]"
                placeholder="Válassza ki az ügyfél státuszát!" />
            <FormKit type="select" name="package_id" label="Tarifacsomag:" validation="required"
                :options="packageOptions" placeholder="Válassza ki az ügyfél tarifacsomagját!" />
            <FormKit type="submit" name="createBtn" label="Felvétel" />
        </FormKit>
    </BaseLayout>
</template>

<script>
import BaseLayout from '@layouts/BaseLayout.vue'
import { usePackageStore } from '@stores/PackageStore.mjs';
import { useCustomerStore } from '@stores/CustomerStore.mjs';
import { mapActions, mapState } from 'pinia';

export default {
    components: {
        BaseLayout,
    },

    computed: {
        ...mapState(usePackageStore, ['packageOptions'])
    },

    methods: {
        ...mapActions(useCustomerStore, ['createCustomer']),
        async newCustomer(customer) {
            await this.createCustomer(customer);
            this.$router.push('/')
            console.log(this.packageOptions)
            console.log(customer)
        }
    }
}
</script>

<route lang="json">{
    "name": "create-customer"
}</route>