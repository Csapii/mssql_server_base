<template>
  <BaseLayout>
    <h1 class="text-center m-10 text-3xl">Tarifacsomagok</h1>
    <div class="flex flex-wrap gap-4">
      <BaseCard v-for="pack in packages" :key="pack.id" :pack />
    </div>
  </BaseLayout>
</template>

<script>
import BaseLayout from '@layouts/BaseLayout.vue'
import BaseCard from '@components/BaseCard.vue';
import { usePackageStore } from '@stores/PackageStore.mjs';
import { mapState, mapActions } from 'pinia'

export default {
  components: {
    BaseLayout,
    BaseCard
  },

  computed: {
    ...mapState(usePackageStore, ['packages'])
  },

  methods: {
    ...mapActions(usePackageStore, ['getPackages'])
  },

  mounted() {
    this.getPackages();
  }
}
</script>

<route lang="json">{
  "name": "home"
}</route>