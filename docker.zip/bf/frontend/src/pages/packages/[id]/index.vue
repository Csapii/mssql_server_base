<template>
    <BaseLayout>
        <div v-if="!loading">
            <h1 class="text-center m-10 text-3xl">{{ package.name }}</h1>
            <BaseTable :customers="filteredCustomers"/>
        </div>
    </BaseLayout>
</template>

<script>
import BaseLayout from '@layouts/BaseLayout.vue';
import BaseTable from '@components/BaseTable.vue';
import { usePackageStore } from '@stores/PackageStore.mjs';
import { useCustomerStore } from '@stores/CustomerStore.mjs';
import { mapActions, mapState } from 'pinia';

export default {
    components: {
        BaseLayout,
        BaseTable
    },

    data() {
        return {
            package: null,
            filteredCustomers: []
        }
    },

    methods: {
        ...mapActions(usePackageStore, ['getPackage']),
    },

    computed: {
        ...mapState(useCustomerStore, ['customers']),
        loading() {
            return this.package === null;
        },
    },

    async mounted() {
        this.package = await this.getPackage(this.$route.params.id);
        this.filteredCustomers = this.customers.filter(x => x.package_id === this.package.id);
    }
}

</script>

<route lang="json">{
    "name": "single-package"
}</route>