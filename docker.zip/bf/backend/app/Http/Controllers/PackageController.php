<?php

namespace App\Http\Controllers;

use App\Http\Resources\PackageResource;
use App\Models\Customer;
use App\Models\Package;
use Illuminate\Http\Request;

class PackageController extends Controller
{
    public function index()
    {
        return response()->json(Package::with('customers')->get());
    }

    public function show($id)
    {
        $package = Package::with('customers')->findOrFail($id);
        return response()->json($package);
    }
}
