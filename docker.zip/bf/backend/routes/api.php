<?php

use App\Http\Controllers\CustomerController;
use App\Http\Controllers\PackageController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::get('packages', [PackageController::class, 'index'])
    ->name('package.index');
Route::get('packages/{package}', [PackageController::class, 'show'])
    ->name('package.show');

Route::get('customers', [CustomerController::class, 'index'])
    ->name('customers.index');
Route::post('customers', [CustomerController::class, 'store'])
    ->name('customers.store');