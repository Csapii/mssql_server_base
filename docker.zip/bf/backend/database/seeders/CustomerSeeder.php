<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CustomerSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('customers')->insert([
            ['id' => 1, 'name' => 'Kovács Péter', 'birth' => 1985, 'business' => false, 'package_id' => 1, 'created_at' => NULL, 'updated_at' => NULL],
            ['id' => 2, 'name' => 'Nagy Anna', 'birth' => 1992, 'business' => false, 'package_id' => 5, 'created_at' => NULL, 'updated_at' => NULL],
            ['id' => 3, 'name' => 'Szabó Zoltán', 'birth' => 1978, 'business' => true, 'package_id' => 10, 'created_at' => NULL, 'updated_at' => NULL],
            ['id' => 4, 'name' => 'Tóth Erika', 'birth' => 2000, 'business' => false, 'package_id' => 15, 'created_at' => NULL, 'updated_at' => NULL],
            ['id' => 5, 'name' => 'Farkas Gábor', 'birth' => 1990, 'business' => true, 'package_id' => 20, 'created_at' => NULL, 'updated_at' => NULL],
            ['id' => 6, 'name' => 'Horváth László', 'birth' => 1982, 'business' => false, 'package_id' => 2, 'created_at' => NULL, 'updated_at' => NULL],
            ['id' => 7, 'name' => 'Balogh Zsuzsanna', 'birth' => 1995, 'business' => true, 'package_id' => 8, 'created_at' => NULL, 'updated_at' => NULL],
            ['id' => 8, 'name' => 'Kiss Márton', 'birth' => 1976, 'business' => false, 'package_id' => 12, 'created_at' => NULL, 'updated_at' => NULL],
            ['id' => 9, 'name' => 'Varga Eszter', 'birth' => 2001, 'business' => true, 'package_id' => 7, 'created_at' => NULL, 'updated_at' => NULL],
            ['id' => 10, 'name' => 'Molnár Péter', 'birth' => 1988, 'business' => false, 'package_id' => 4, 'created_at' => NULL, 'updated_at' => NULL],
            ['id' => 11, 'name' => 'Tóth Lilla', 'birth' => 1993, 'business' => true, 'package_id' => 9, 'created_at' => NULL, 'updated_at' => NULL],
            ['id' => 12, 'name' => 'Szilágyi Gergő', 'birth' => 1980, 'business' => false, 'package_id' => 14, 'created_at' => NULL, 'updated_at' => NULL],
            ['id' => 13, 'name' => 'Fekete Tamás', 'birth' => 1974, 'business' => true, 'package_id' => 6, 'created_at' => NULL, 'updated_at' => NULL],
            ['id' => 14, 'name' => 'Lukács Barbara', 'birth' => 2003, 'business' => false, 'package_id' => 3, 'created_at' => NULL, 'updated_at' => NULL],
            ['id' => 15, 'name' => 'Németh Norbert', 'birth' => 1986, 'business' => true, 'package_id' => 5, 'created_at' => NULL, 'updated_at' => NULL],
            ['id' => 16, 'name' => 'Juhász Krisztina', 'birth' => 1999, 'business' => false, 'package_id' => 11, 'created_at' => NULL, 'updated_at' => NULL],
            ['id' => 17, 'name' => 'Kádár Lajos', 'birth' => 1969, 'business' => true, 'package_id' => 13, 'created_at' => NULL, 'updated_at' => NULL],
            ['id' => 18, 'name' => 'Oláh Brigitta', 'birth' => 1991, 'business' => false, 'package_id' => 16, 'created_at' => NULL, 'updated_at' => NULL],
            ['id' => 19, 'name' => 'Papp Roland', 'birth' => 1977, 'business' => true, 'package_id' => 18, 'created_at' => NULL, 'updated_at' => NULL],
            ['id' => 20, 'name' => 'Sipos Anikó', 'birth' => 1983, 'business' => false, 'package_id' => 19, 'created_at' => NULL, 'updated_at' => NULL],
            ['id' => 21, 'name' => 'Vass László', 'birth' => 1981, 'business' => true, 'package_id' => 21, 'created_at' => NULL, 'updated_at' => NULL],
            ['id' => 22, 'name' => 'Simon Veronika', 'birth' => 1997, 'business' => false, 'package_id' => 22, 'created_at' => NULL, 'updated_at' => NULL],
            ['id' => 23, 'name' => 'Bodnár Gergely', 'birth' => 1975, 'business' => true, 'package_id' => 23, 'created_at' => NULL, 'updated_at' => NULL],
            ['id' => 24, 'name' => 'Pál Judit', 'birth' => 2002, 'business' => false, 'package_id' => 24, 'created_at' => NULL, 'updated_at' => NULL],
            ['id' => 25, 'name' => 'Major László', 'birth' => 1984, 'business' => true, 'package_id' => 25, 'created_at' => NULL, 'updated_at' => NULL],
            ['id' => 26, 'name' => 'Dénes Csilla', 'birth' => 1998, 'business' => false, 'package_id' => 26, 'created_at' => NULL, 'updated_at' => NULL],
            ['id' => 27, 'name' => 'Kovács Dániel', 'birth' => 1994, 'business' => true, 'package_id' => 1, 'created_at' => NULL, 'updated_at' => NULL],
            ['id' => 28, 'name' => 'Takács Edit', 'birth' => 1987, 'business' => false, 'package_id' => 23, 'created_at' => NULL, 'updated_at' => NULL],
            ['id' => 29, 'name' => 'Bognár Zsolt', 'birth' => 1979, 'business' => true, 'package_id' => 2, 'created_at' => NULL, 'updated_at' => NULL],
            ['id' => 30, 'name' => 'Fehér Géza', 'birth' => 1985, 'business' => false, 'package_id' => 25, 'created_at' => NULL, 'updated_at' => NULL],
        ]);
    }
}
