<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class PackageSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('packages')->insert([
            [
                'id' => 1,
                'name' => '5 GB Net + Mobil M',
                'price' => 5990,
                'type' => 'mobile',
                'created_at' => NULL,
                'updated_at' => NULL,
            ],
            [
                'id' => 2,
                'name' => '5 GB Net + Mobil L',
                'price' => 9890,
                'type' => 'mobile',
                'created_at' => NULL,
                'updated_at' => NULL,
            ],
            [
                'id' => 3,
                'name' => '5 GB Net + Mobil XL',
                'price' => 13190,
                'type' => 'mobile',
                'created_at' => NULL,
                'updated_at' => NULL,
            ],
            [
                'id' => 4,
                'name' => '15 GB Net + Mobil S',
                'price' => 6690,
                'type' => 'mobile',
                'created_at' => NULL,
                'updated_at' => NULL,
            ],
            [
                'id' => 5,
                'name' => '15 GB Net + Mobil M',
                'price' => 8990,
                'type' => 'mobile',
                'created_at' => NULL,
                'updated_at' => NULL,
            ],
            [
                'id' => 6,
                'name' => '15 GB Net + Mobil L',
                'price' => 12890,
                'type' => 'mobile',
                'created_at' => NULL,
                'updated_at' => NULL,
            ],
            [
                'id' => 7,
                'name' => '15 GB Net + Mobil XL',
                'price' => 16190,
                'type' => 'mobile',
                'created_at' => NULL,
                'updated_at' => NULL,
            ],
            [
                'id' => 8,
                'name' => '60 GB Net + Mobil S',
                'price' => 9690,
                'type' => 'mobile',
                'created_at' => NULL,
                'updated_at' => NULL,
            ],
            [
                'id' => 9,
                'name' => '60 GB Net + Mobil M',
                'price' => 11990,
                'type' => 'mobile',
                'created_at' => NULL,
                'updated_at' => NULL,
            ],
            [
                'id' => 10,
                'name' => '60 GB Net + Mobil L',
                'price' => 15890,
                'type' => 'mobile',
                'created_at' => NULL,
                'updated_at' => NULL,
            ],
            [
                'id' => 11,
                'name' => '60 GB Net + Mobil XL',
                'price' => 19190,
                'type' => 'mobile',
                'created_at' => NULL,
                'updated_at' => NULL,
            ],
            [
                'id' => 12,
                'name' => 'Korlátlan Net + Mobil M',
                'price' => 15090,
                'type' => 'mobile',
                'created_at' => NULL,
                'updated_at' => NULL,
            ],
            [
                'id' => 13,
                'name' => 'Korlátlan Net + Mobil L',
                'price' => 18990,
                'type' => 'mobile',
                'created_at' => NULL,
                'updated_at' => NULL,
            ],
            [
                'id' => 14,
                'name' => 'Korlátlan Net + Mobil XL',
                'price' => 2290,
                'type' => 'mobile',
                'created_at' => NULL,
                'updated_at' => NULL,
            ],
            [
                'id' => 15,
                'name' => '250 Net + TV S',
                'price' => 10064,
                'type' => 'home',
                'created_at' => NULL,
                'updated_at' => NULL,
            ],
            [
                'id' => 16,
                'name' => '250 Net + TV M',
                'price' => 12454,
                'type' => 'home',
                'created_at' => NULL,
                'updated_at' => NULL,
            ],
            [
                'id' => 17,
                'name' => '250 Net + TV L',
                'price' => 13164,
                'type' => 'home',
                'created_at' => NULL,
                'updated_at' => NULL,
            ],
            [
                'id' => 18,
                'name' => '500 Net + TV S',
                'price' => 11536,
                'type' => 'home',
                'created_at' => NULL,
                'updated_at' => NULL,
            ],
            [
                'id' => 19,
                'name' => '500 Net + TV M',
                'price' => 13926,
                'type' => 'home',
                'created_at' => NULL,
                'updated_at' => NULL,
            ],
            [
                'id' => 20,
                'name' => '500 Net + TV L',
                'price' => 14636,
                'type' => 'home',
                'created_at' => NULL,
                'updated_at' => NULL,
            ],
            [
                'id' => 21,
                'name' => '1000 Net + TV S',
                'price' => 12168,
                'type' => 'home',
                'created_at' => NULL,
                'updated_at' => NULL,
            ],
            [
                'id' => 22,
                'name' => '1000 Net + TV M',
                'price' => 14558,
                'type' => 'home',
                'created_at' => NULL,
                'updated_at' => NULL,
            ],
            [
                'id' => 23,
                'name' => '1000 Net + TV L',
                'price' => 15268,
                'type' => 'home',
                'created_at' => NULL,
                'updated_at' => NULL,
            ],
            [
                'id' => 24,
                'name' => '2000 Net + TV S',
                'price' => 14296,
                'type' => 'home',
                'created_at' => NULL,
                'updated_at' => NULL,
            ],
            [
                'id' => 25,
                'name' => '2000 Net + TV M',
                'price' => 16686,
                'type' => 'home',
                'created_at' => NULL,
                'updated_at' => NULL,
            ],
            [
                'id' => 26,
                'name' => '2000 Net + TV L',
                'price' => 17396,
                'type' => 'home',
                'created_at' => NULL,
                'updated_at' => NULL,
            ],
        ]);
    }
}
