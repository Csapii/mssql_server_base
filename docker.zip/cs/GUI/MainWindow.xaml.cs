﻿using SportirodaLib;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SportirodaGUI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Adatok adatok;

        public MainWindow()
        {
            Adatok.InitCSV();
            InitializeComponent();
            adatok = Adatok.Instance;
            LoadVersenyTipusok();
        }

        private void LoadVersenyTipusok()
        {
            tipusComboBox.Items.Clear();
            foreach (var tipus in adatok.Tipusok)
            {
                tipusComboBox.Items.Add(tipus.Nev);
            }
        }

        private void tipusComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            datumComboBox.Items.Clear();
            datumComboBox.SelectedItem = null;

            var selectedTipus = tipusComboBox.SelectedItem.ToString();
            LoadVersenyDatumok(selectedTipus);
        }

        private void LoadVersenyDatumok(string tipusNev)
        {
            var tipusId = adatok.Tipusok.First(t => t.Nev == tipusNev).TipusId;
            var versenyek = adatok.Versenyek.Where(v => v.TipusId == tipusId).ToList();

            foreach (var verseny in versenyek)
            {
                datumComboBox.Items.Add(verseny.Datum.ToString("yyyy-MM-dd"));
            }
        }

        private void datumComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (datumComboBox.SelectedItem != null)
            {
                var selectedDatum = datumComboBox.SelectedItem.ToString();
                DisplayVersenyAdatok(selectedDatum);
            }
            else
            {
                versenyAdatokTextBox.Clear();
            }
        }

        private void DisplayVersenyAdatok(string datum)
        {
            var verseny = adatok.Versenyek.First(v => v.Datum.ToString("yyyy-MM-dd") == datum);
            versenyAdatokTextBox.Text = $"Nevezési díj: {verseny.NevezesiDij} HUF\nKezdésidő: {verseny.Kezdesido}\nSzintidő: {verseny.Szintido}";
        }
    }
}