﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SportirodaLib
{
    public class Nevezes
    {
        public int NevezesId { get; init; }
        public int VersenyId { get; init; }
        public int VersenyzoId { get; init; }

        public Nevezes(string dataString)
        {
            string[] data = dataString.Split(';');
            NevezesId = int.Parse(data[0]);
            VersenyId = int.Parse(data[1]);
            VersenyzoId = int.Parse(data[2]);
        }
    }
}
