﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SportirodaLib
{
    public class Adatok
    {
        public readonly List<Verseny> Versenyek;
        public readonly List<Tipus> Tipusok;
        public readonly List<Versenyzo> Versenyzok;
        public readonly List<Nevezes> Nevezesek;

        private Adatok()
        {
            Versenyek = File
                .ReadAllLines("Data\\verseny.csv")
                .Skip(1)
                .Select(x => new Verseny(x))
                .ToList();

            Tipusok = File
                .ReadAllLines("Data\\tipus.csv")
                .Skip(1)
                .Select(x => new Tipus(x))
                .ToList();

            Versenyzok = File
                .ReadAllLines("Data\\versenyzo.csv")
                .Skip(1)
                .Select(x => new Versenyzo(x))
                .ToList();

            Nevezesek = File
                .ReadAllLines("Data\\nevezes.csv")
                .Skip(1)
                .Select(x => new Nevezes(x))
                .ToList();
        }
        public static Adatok? Instance { get; private set; }
        public static void InitCSV()
        {
            if (Instance is not null)
            {
                throw new InvalidOperationException("Already Initialized!");
            }
            else
            {
                Instance = new Adatok();
            }
        }

        public decimal CalculateRevenue(int versenyId)
        {
            var verseny = Versenyek.FirstOrDefault(v => v.VersenyId == versenyId);
            if (verseny == null)
            {
                return 0;
            }

            int participantsCount = Nevezesek.Count(n => n.VersenyId == versenyId);

            return verseny.NevezesiDij * participantsCount;
        }
        public int CountRacesInApril()
        {
            return Versenyek.Count(v => v.Datum.Month == 4);
        }
        public Versenyzo? GetVersenyzoDetails(string name)
        {
            var versenyzo = Versenyzok.FirstOrDefault(v => v.Nev.Equals(name, StringComparison.OrdinalIgnoreCase));

            if (versenyzo == null)
            {
                return null;
            }
            return versenyzo;
        }
        public IEnumerable<KeyValuePair<string, decimal>> Top3RevenueRaces()
        {
            Dictionary<int, decimal> revenueByRace = new Dictionary<int, decimal>();

            foreach (var verseny in Versenyek)
            {
                decimal revenue = CalculateRevenue(verseny.VersenyId);
                revenueByRace.Add(verseny.VersenyId, revenue);
            }
            Dictionary<string, decimal> raceWithRevenue = new Dictionary<string, decimal>();

            foreach (var item in revenueByRace)
            {
                var verseny = Versenyek.First(v => v.VersenyId == item.Key);
                var tipus = Tipusok.First(t => t.TipusId == verseny.TipusId);

                raceWithRevenue.Add($"{verseny.Datum.ToString("yyyy.MM.dd")} ({tipus.Nev})", item.Value);
            }
            return raceWithRevenue.OrderByDescending(x => x.Value).Take(3);
        }

    }
}
