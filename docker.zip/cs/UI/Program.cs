﻿using SportirodaLib;

Adatok.InitCSV();

// 5. feladat:
int aprilRacesCount = Adatok.Instance.CountRacesInApril();
Console.WriteLine($"5. feladat: {aprilRacesCount} verseny esett áprilisra");

// 6. feladat:
string competitorName = "Megyeri Edina";
var competitor = Adatok.Instance.GetVersenyzoDetails(competitorName);

Console.WriteLine("6. feladat: A versenyző neve: " + competitorName);
if (competitor != null)
{
    Console.WriteLine($"Születési idő: {competitor.Szuldatum.ToString("yyyy.MM.dd.")}");
    Console.WriteLine($"Nem: {(competitor.Nem == 1 ? "férfi" : "nő")}");
    Console.WriteLine($"Email: {competitor.Email}");
}
else
{
    Console.WriteLine("Ilyen néven nem található versenyző");
}

// 7. feladat:
var top3RevenueRaces = Adatok.Instance.Top3RevenueRaces();
Console.WriteLine("7. feladat: A 3 legmagasabb bevételű verseny:");
foreach (var race in top3RevenueRaces)
{
    var raceDetails = race.Key.Split(' ');
    Console.WriteLine($"{raceDetails[0]} {raceDetails[1]}: {race.Value} Ft");
}

Console.ReadKey();